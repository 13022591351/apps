#include "unicore.h"
#include "unicore_debug.h"

#define NMEA_SERIAL_DEVPATH "/dev/ttyS1"
#define RTCM_SERIAL_DEVPATH "/dev/ttyS2"
#define CONSOLE_DEVPATH     "/dev/console"

#define NMEA_CMD "\
UNLOG\r\n\
GPGGA 1\r\n\
GPGSA 1\r\n\
GPGSV 1\r\n\
GPVTG 1\r\n\
\r\n"

// RTCM1005 RTK 基准站天线参考点坐标（ARP）
// RTCM1033 接收机与天线说明
// RTCM1125 BDS MSM5（全部伪距、载波、多普勒和 CNR 观测值）
// RTCM1075 GPS MSM5（全部伪距、载波、多普勒和 CNR 观测值）
// RTCM1085 GLONASS MSM5（全部伪距、载波、多普勒和 CNR 观测值）

Unicore::Unicore() {

}

Unicore::~Unicore() {
    uni_close();
}

int Unicore::uni_open(void) {
    int ret;

    ret = m_nmea_init();
    if (ret < 0) {
        dbg_err("ERROR! UniCore NMEA Init Failed\n");
        return -1;
    }

#if defined(CONFIG_DYW_UNICORE_RTCM_PROXY)

    ret = m_rtcm_init();
    if (ret < 0) {
        dbg_err("ERROR! UniCore RTCM Init Failed\n");
        return -1;
    }

#endif

    return ret;
}

int Unicore::uni_close(void) {
    int ret;

    ret = m_nmea_deinit();
    if (ret < 0) {
        dbg_err("ERROR! UniCore NMEA DeInit Failed\n");
    }

#if defined(CONFIG_DYW_UNICORE_RTCM_PROXY)

    ret = m_rtcm_deinit();
    if (ret < 0) {
        dbg_err("ERROR! UniCore RTCM DeInit Failed\n");
    }

#endif

    return ret;
}

void Unicore::uni_update(void) {
    m_nmea_update();

    if (OK == m_sub_rtcm_ntrip->subscribe()) {
        {
            decltype(m_sub_rtcm_ntrip->meta_data()) &topic = m_sub_rtcm_ntrip->meta_data();
            const orb_abstime now = orb_absolute_time();

            printf("orb_rtcm_ntrip : ttimestamp: %" PRIu64 " (%" PRIu64 " us ago)\n",
                    topic.timestamp,
                    now - topic.timestamp);
        }
    }

#if defined(CONFIG_DYW_UNICORE_RTCM_PROXY)

    m_rtcm_update();

#endif
}

int Unicore::m_nmea_init(void) {
    m_nmea_line.resize(NMEA_MAX_LENGTH);

    m_nmea_fd = open(NMEA_SERIAL_DEVPATH, O_RDWR | O_NONBLOCK);
    if (m_nmea_fd < 0) {
        dbg_err("Unable to open file %s\n", NMEA_SERIAL_DEVPATH);
        return -1;
    }
    fcntl(m_nmea_fd, F_SETFL, 0);

    fcntl(m_nmea_fd, TCFLSH, 0);
    write(m_nmea_fd, NMEA_CMD, strlen(NMEA_CMD));
    usleep(10 * 1000);
    fcntl(m_nmea_fd, TCFLSH, 0);

    m_pub_gga_raw    = new Pub_Helper<orb_gps_raw_gga_t>(ORB_ID(orb_gps_gga_raw));
    m_sub_rtcm_ntrip = new Sub_Helper<orb_rtcm_t>(ORB_ID(orb_rtcm_ntrip));

    m_pub_gga_raw->meta_data().gga_raw[0] = '\0';

    return m_nmea_fd;
}

int Unicore::m_nmea_deinit(void) {
    if (m_nmea_fd) {
        close(m_nmea_fd);
        m_nmea_fd = 0;
    }

    if (m_pub_gga_raw) {
        delete m_pub_gga_raw;
        m_pub_gga_raw = nullptr;
    }

    if (m_sub_rtcm_ntrip) {
        delete m_sub_rtcm_ntrip;
        m_sub_rtcm_ntrip = nullptr;
    }

    return 0;
}

void Unicore::m_nmea_update(void) {
    int     read_len                        { 0 };
    uint8_t reab_buf[NMEA_MAX_LENGTH / 2] = { 0 };

    ioctl(m_nmea_fd, FIONREAD, &read_len);
    if (read_len <= 0) {
        return;
    }
    read_len = read(m_nmea_fd, reab_buf, NMEA_MAX_LENGTH / 2);
    if (static_cast<int>(m_nmea_line.length()) > NMEA_MAX_LENGTH - read_len) {
        m_nmea_line.erase(read_len);
    }
    m_nmea_line.append((char *)reab_buf, read_len);

    while (true) {
        std::string::size_type loc_f = m_nmea_line.find("$");
        if (loc_f == std::string::npos) {
            m_nmea_line.clear();
            return;
        }
        else {
            m_nmea_line.erase(0, loc_f);

            std::string::size_type loc_rn = m_nmea_line.find("\r\n");
            if (loc_rn == std::string::npos) {
                return;
            }
            m_nmea_line[loc_rn] = '\0';

            switch (m_nmea_line[1]) {
                case ('G'): {
                    m_nmea_decode();
                    break;
                }
                case ('c'): {
                    break;
                }
                default: {
                    break;
                }
            }

            m_nmea_line.erase(0, loc_rn);
        }
    }

    // while (true) {
    //     std::string::size_type loc_gp = m_nmea_line.find("$G");
    //     if (loc_gp == std::string::npos) {
    //         m_nmea_line.clear();
    //         return;
    //     }
    //     else {
    //         m_nmea_line.erase(0, loc_gp);

    //         std::string::size_type loc_rn = m_nmea_line.find("\r\n");
    //         if (loc_rn == std::string::npos) {
    //             return;
    //         }
    //         m_nmea_line[loc_rn] = '\0';
    //         m_nmea_decode();
    //         m_nmea_line.erase(0, loc_rn);
    //     }
    // }
}

void Unicore::m_nmea_decode(void) {
    switch (minmea_sentence_id(m_nmea_line.c_str(), false)) {
        case (MINMEA_SENTENCE_RMC): {   // GPRMC 卫星定位信息
            minmea_sentence_rmc frame;

            if (minmea_parse_rmc(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxRMC sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_SENTENCE_GGA): {   // GPGGA 卫星定位信息
            minmea_sentence_gga frame;

            if (minmea_parse_gga(&frame, m_nmea_line.c_str())) {
                // dbg_info("Fix quality....................: %d\n",  frame.fix_quality);
                // dbg_info("Altitude.......................: %ld\n", frame.altitude.value);
                // dbg_info("Tracked satellites.............: %d\n",  frame.satellites_tracked);
            }
            else {
                dbg_info("$xxGGA sentence is not parsed\n");
            }

            {
                decltype(m_pub_gga_raw->meta_data()) &topic = m_pub_gga_raw->meta_data();

                strcpy((char *)topic.gga_raw, m_nmea_line.c_str());
                // strcpy((char *)topic.gga_raw, "$GNGGA,044744.00,3122.4658,N,12025.2791,E,1,10,3.00,12.575,M,7.100,M,00,0000*5F");
                topic.timestamp = orb_absolute_time();
                if (OK != m_pub_gga_raw->publish()) {
                    dbg_err("ERROR! orb_gps_gga_raw Pub Failed\n");
                }
            }

            {
                decltype(m_pub_rtcm_unicore->meta_data()) &topic = m_pub_rtcm_unicore->meta_data();

                topic.timestamp = orb_absolute_time();
                if (OK != m_pub_rtcm_unicore->publish()) {
                    dbg_err("ERROR! orb_rtcm_unicore Pub Failed\n");
                }
            }

            break;
        }
        case (MINMEA_SENTENCE_GSA): {   // GPGSA 参与定位解算的卫星信息
            minmea_sentence_gsa frame;

            if (minmea_parse_gsa(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxGSA sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_SENTENCE_GLL): {   // GPGLL 地理位置信息
            minmea_sentence_gll frame;

            if (minmea_parse_gll(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxGLL sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_SENTENCE_GST): {   // GPGST 伪距观测误差信息
            minmea_sentence_gst frame;

            if (minmea_parse_gst(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxGST sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_SENTENCE_GSV): {   // GPGSV 可视卫星信息
            minmea_sentence_gsv frame;

            if (minmea_parse_gsv(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxGSV sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_SENTENCE_GBS): {   // GPGBS 卫星故障检测信息
            minmea_sentence_gbs frame;

            if (minmea_parse_gbs(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxGBS sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_SENTENCE_VTG): {   // GPVTG 地面航向与速度信息
            minmea_sentence_vtg frame;

            if (minmea_parse_vtg(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxVTG sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_SENTENCE_ZDA): {   // GPZDA 日期和时间
            minmea_sentence_zda frame;

            if (minmea_parse_zda(&frame, m_nmea_line.c_str())) {

            }
            else {
                dbg_info("$xxZDA sentence is not parsed\n");
            }

            break;
        }
        case (MINMEA_INVALID): {
            
            break;
        }
        case (MINMEA_UNKNOWN): {
            
            break;
        }
    }
}

#if defined(CONFIG_DYW_UNICORE_RTCM_PROXY)

int Unicore::m_rtcm_init(void) {
    m_rtcm_fd = open(RTCM_SERIAL_DEVPATH, O_RDWR);
    if (m_rtcm_fd < 0) {
        dbg_err("Unable to open file %s\n", RTCM_SERIAL_DEVPATH);
        return -1;
    }
    fcntl(m_rtcm_fd, F_SETFL, 0);

    m_pub_rtcm_unicore = new Pub_Helper<orb_rtcm_t>(ORB_ID(orb_rtcm_unicore));
    m_pub_rtcm_unicore->meta_data().rtcm_len = 0;

    return m_rtcm_fd;
}

int Unicore::m_rtcm_deinit(void) {
    if (m_rtcm_fd) {
        close(m_rtcm_fd);
        m_rtcm_fd = 0;
    }

    if (m_pub_rtcm_unicore) {
        delete m_pub_rtcm_unicore;
        m_pub_rtcm_unicore = nullptr;
    }

    return 0;
}

void Unicore::m_rtcm_update(void) {
    int     read_len                        { 0 };
    uint8_t reab_buf[RTCM_MAX_LENGTH / 2] = { 0 };

    ioctl(m_rtcm_fd, FIONREAD, &read_len);
    if (read_len <= 0) {
        return;
    }
    read_len = read(m_rtcm_fd, reab_buf, RTCM_MAX_LENGTH / 2);

    {
        decltype(m_pub_rtcm_unicore->meta_data()) &topic = m_pub_rtcm_unicore->meta_data();

        topic.timestamp = orb_absolute_time();
        topic.rtcm_len  = read_len;
        memcpy(topic.rtcm, reab_buf, read_len);
        if (OK != m_pub_rtcm_unicore->publish()) {
            dbg_err("ERROR! orb_rtcm_unicore Pub Failed\n");
        }
    }
}

#endif
