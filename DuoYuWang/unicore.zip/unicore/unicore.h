#pragma once

#include <nuttx/config.h>

#include <stdio.h>
#include <fcntl.h>
#include <wchar.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>

#include <string>
#include <memory>

#include <minmea/minmea.h>

#include <uorb_fmu.h>
#include <uorb_helper.h>

#define NMEA_MAX_LENGTH 512
#define RTCM_MAX_LENGTH 2560

class Unicore {
public:
    explicit Unicore();
    virtual ~Unicore();

    int uni_open(void);
    int uni_close(void);
    void uni_update(void);

private:
    int m_nmea_init(void);
    int m_nmea_deinit(void);
    void m_nmea_update(void);
    void m_nmea_decode(void);

    int                             m_nmea_fd           { 0       };
    std::string                     m_nmea_line;

    Pub_Helper<orb_gps_raw_gga_t>  *m_pub_gga_raw       { nullptr };
    Sub_Helper<orb_rtcm_t>         *m_sub_rtcm_ntrip    { nullptr };


#if defined(CONFIG_DYW_UNICORE_RTCM_PROXY)

    int m_rtcm_init(void);
    int m_rtcm_deinit(void);
    void m_rtcm_update(void);

    int                             m_rtcm_fd          { 0       };

    Pub_Helper<orb_rtcm_t>         *m_pub_rtcm_unicore { nullptr };

#endif

};
